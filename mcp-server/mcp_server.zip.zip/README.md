# AEGIS MCP Server

Orchestration layer for the AEGIS Threat Detection System.  
Receives structured analysis results from FastAPI and dispatches Slack alerts + evidence storage based on severity.

---

## Architecture

```
FastAPI (AI only)
      ↓  POST /process
MCP Server (Node.js :3001)
      ↓
 ┌────────────┬──────────────────┐
 ↓            ↓                  ↓
Slack      Local JSON       Google Drive
Alert      evidence/        (optional)
```

## Severity Decision Table

| Condition                                          | Severity | Actions          |
|----------------------------------------------------|----------|------------------|
| `label == "dangerous"` AND `confidence > 0.9`     | HIGH     | Slack + Store    |
| `label == "suspicious"` OR `0.75 ≤ confidence ≤ 0.9` | MEDIUM | Store only       |
| Everything else                                    | LOW      | None             |

---

## Setup

### 1. Install dependencies

```bash
cd mcp-server
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env with your values
```

Minimum required `.env`:

```env
PORT=3001
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL
STORAGE_BACKEND=local       # or "gdrive"
EVIDENCE_DIR=./evidence
```

### 3. (Optional) Google Drive setup

If using `STORAGE_BACKEND=gdrive`:

1. Create a Google Cloud project
2. Enable the Drive API
3. Create a Service Account and download the JSON key
4. Save the key to `mcp-server/config/gdrive-service-account.json`
5. Share your target Drive folder with the service account email
6. Set `GDRIVE_FOLDER_ID` in `.env`

### 4. Start the server

```bash
# Development (auto-reload)
npm run dev

# Production
npm start
```

### 5. Integrate with FastAPI

Copy `fastapi_integration/mcp_bridge.py` into your FastAPI project:

```python
# In your FastAPI route handler:
from services.mcp_bridge import dispatch_to_mcp
import asyncio

@app.post("/analyze")
async def analyze(request: AnalyzeRequest):
    result = await ai_engine.analyze(request.message)
    
    # Fire-and-forget: MCP handles alerts/storage async
    asyncio.create_task(dispatch_to_mcp(result))
    
    return result  # returns immediately to caller
```

Add to FastAPI `.env`:
```env
MCP_SERVER_URL=http://localhost:3001
MCP_TIMEOUT_SECONDS=5
```

---

## API Reference

### `GET /health`
```json
{
  "status": "ok",
  "service": "AEGIS MCP Server",
  "slack_enabled": true,
  "storage_backend": "local"
}
```

### `POST /process`
Primary endpoint. Receives FastAPI analysis, runs decision logic.

**Request body** (FastAPI analysis JSON):
```json
{
  "label": "dangerous",
  "confidence": 0.97,
  "risk_score": 91.5,
  "reason": "Explicit threat detected.",
  "risk_factors": [
    { "factor": "Violence", "description": "Direct physical threat" }
  ],
  "analysis_id": "abc-123",
  "timestamp": "2025-01-01T00:00:00Z",
  "message": "(optional) original intercepted text"
}
```

**Response**:
```json
{
  "status": "processed",
  "severity": "HIGH",
  "actions_taken": ["alert", "stored"],
  "detail": {
    "alert": { "success": true },
    "store": { "success": true, "path": "./evidence/evidence_abc-123_..." }
  }
}
```

### `POST /trigger-alert`
Directly fire a Slack alert. Bypasses decision logic.

### `POST /store-evidence`
Directly store evidence. Bypasses decision logic.

---

## Testing

### Automated tests

```bash
# Start server first
npm run dev

# In another terminal
npm test
```

### Postman

Import these requests:

**1. Health check**
- `GET http://localhost:3001/health`

**2. HIGH severity (Slack + Store)**
- `POST http://localhost:3001/process`
- Body (JSON):
```json
{
  "label": "dangerous",
  "confidence": 0.97,
  "risk_score": 91.5,
  "reason": "Explicit threat to cause harm.",
  "risk_factors": [
    { "factor": "Violence", "description": "Direct physical threat" }
  ],
  "analysis_id": "postman-test-high-001",
  "timestamp": "2025-01-01T12:00:00Z",
  "message": "I will harm everyone at the event."
}
```

**3. MEDIUM severity (Store only)**
```json
{
  "label": "suspicious",
  "confidence": 0.82,
  "risk_score": 62.0,
  "reason": "Suspicious patterns detected.",
  "risk_factors": [],
  "analysis_id": "postman-test-medium-001",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

**4. LOW severity (No action)**
```json
{
  "label": "safe",
  "confidence": 0.55,
  "risk_score": 10.0,
  "reason": "No harmful intent.",
  "risk_factors": [],
  "analysis_id": "postman-test-low-001",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### cURL quick test

```bash
curl -X POST http://localhost:3001/process \
  -H "Content-Type: application/json" \
  -d '{
    "label": "dangerous",
    "confidence": 0.97,
    "risk_score": 91.5,
    "reason": "Test threat",
    "risk_factors": [],
    "analysis_id": "curl-test-001",
    "timestamp": "2025-01-01T00:00:00Z"
  }'
```

---

## Project Structure

```
mcp-server/
├── src/
│   ├── app.js                    # Express bootstrap
│   ├── config/
│   │   └── env.js                # All env vars in one place
│   ├── routes/
│   │   └── process.js            # Route definitions
│   ├── controllers/
│   │   └── processController.js  # Request handlers + orchestration
│   ├── services/
│   │   ├── decisionEngine.js     # Severity logic
│   │   ├── slackService.js       # Slack webhook (matches AEGIS format)
│   │   └── storageService.js     # Local JSON + Google Drive
│   └── utils/
│       └── logger.js             # Structured JSON logger
├── fastapi_integration/
│   └── mcp_bridge.py             # Drop-in async bridge for FastAPI
├── tests/
│   └── test.js                   # Integration smoke tests
├── evidence/                     # Auto-created by storageService
├── .env.example
└── package.json
```
